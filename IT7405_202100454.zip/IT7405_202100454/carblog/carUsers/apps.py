from django.apps import AppConfig


class CarusersConfig(AppConfig):
    name = 'carUsers'
