from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Car  # Update this line to import Car instead of Post
from .forms import PostForm
from django.urls import reverse_lazy
from django.shortcuts import redirect

class HomeView(ListView):
    model = Car
    template_name = 'home.html'
    ordering = ['-id']
    context_object_name = 'car_list'  # Update to 'car_list'

    def get_queryset(self):
        car_type = self.request.GET.get('car_type', '')
        if car_type:
            return Car.objects.filter(car_type=car_type)
        else:
            return Car.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['car_types'] = [choice[0] for choice in Car.CAR_TYPE_CHOICES]
        return context


class CarDetailView(DetailView):
    model = Car
    template_name = 'car_detail.html'



class AddCarView(CreateView):
    model = Car
    form_class = PostForm
    template_name = 'add_car.html'

    def form_valid(self, form):
        response = super().form_valid(form)
        return redirect('car-detail', pk=self.object.pk)
    
class UpdateCarView(UpdateView):
    model = Car
    form_class = PostForm
    template_name = 'edit_car.html'

class DeleteCarView(DeleteView):
    model = Car
    template_name = 'delete_car.html'
    success_url = reverse_lazy('home')

