# cartodo/models.py
from django.db import models
from django.urls import reverse

class Car(models.Model):
    SEDAN = 'Sedan'
    COUPE = 'Coupe'
    CONVERTIBLE = 'Convertible'
    SUV = 'SUV'
    TRUCK = 'Truck'
    SPORTS_CAR = 'Sports Car'

    CAR_TYPE_CHOICES = [
        (SEDAN, 'Sedan'),
        (COUPE, 'Coupe'),
        (CONVERTIBLE, 'Convertible'),
        (SUV, 'SUV'),
        (TRUCK, 'Truck'),
        (SPORTS_CAR, 'Sports Car'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()
    car_type = models.CharField(max_length=255, choices=CAR_TYPE_CHOICES)
    header_image = models.ImageField(null=True, blank=True, upload_to="images/")

    def __str__(self):
        return f'{self.title}'

    def get_absolute_url(self):
        return reverse("car-detail", args=(str(self.id),))
