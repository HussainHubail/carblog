from django.apps import AppConfig


class CartodoConfig(AppConfig):
    name = 'cartodo'
