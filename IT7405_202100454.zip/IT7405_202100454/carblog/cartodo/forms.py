# cartodo/forms.py
from django import forms
from .models import Car

class PostForm(forms.ModelForm):
    class Meta:
        model = Car  # Update to use Car model instead of Post
        fields = ("title", "description", "car_type", 'header_image')  # Update field names

        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control'}),
            'car_type': forms.Select(attrs={'class': 'form-control'}),
        }
