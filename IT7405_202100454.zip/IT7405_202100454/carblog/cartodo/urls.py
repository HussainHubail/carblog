from django.urls import path
from .views import HomeView, CarDetailView, AddCarView, UpdateCarView, DeleteCarView

urlpatterns = [
    path('', HomeView.as_view(), name="home"),
    path('Car/<int:pk>/', CarDetailView.as_view(), name='car-detail'),
    path('add_car/', AddCarView.as_view(), name='add-car'),
    path('car/edit/<int:pk>/', UpdateCarView.as_view(), name='edit-car'),  # Include the primary key parameter
    path('car/delete/<int:pk>/', DeleteCarView.as_view(), name='delete-car'),  # Include the primary key parameter
]
