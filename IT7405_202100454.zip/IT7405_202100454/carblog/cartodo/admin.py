from django.contrib import admin
from .models import Car  # Update the import statement

@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ['title', 'car_type', 'description', 'header_image']  # Adjust the fields as needed
    search_fields = ['title', 'car_type']
