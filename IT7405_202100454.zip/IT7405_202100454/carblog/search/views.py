# views.py in the search app
from django.shortcuts import render
from cartodo.models import Car

def search_view(request):
    query = request.GET.get('query', '')

    if query:
        # Perform the search if the query is not empty
        results = Car.objects.filter(title__icontains=query)
    else:
        results = []

    context = {'query': query, 'results': results}
    return render(request, 'search/search_results.html', context)
